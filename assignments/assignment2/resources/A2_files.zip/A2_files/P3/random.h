#ifndef RANDOM_H
#define RANDOM_H

void randomPoint(double & x, double & y);

#endif