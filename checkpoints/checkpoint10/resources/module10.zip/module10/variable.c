#include<stdio.h>
int main(){
     int a=0;
     for (int i = 0 ; i < 10 ; i++){
          a+=i;
     }
     printf ("%d", a);

     return 0;

}
